package com.example.startaste10;

public class StyleInfo {
    public String stylename;
    public String styleexplane;
    public int maxprogress;
    public int progress;

    public StyleInfo(String stylename, String styleexplane, int maxprogress, int progress) {
        this.stylename = stylename;
        this.styleexplane = styleexplane;
        this.maxprogress = maxprogress;
        this.progress = progress;
    }
}
